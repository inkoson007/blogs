if (not bLogs_ReplacedServerLog) then
	bLogs_ReplacedServerLog = ServerLog
	function ServerLog(...)
		if (bLogs.InGameConfig) then
			if (bLogs.InGameConfig.General.DisableServerLog == false) then
				bLogs_ReplacedServerLog(...)
			end
		end
	end
end
bLogs:hook("canSeeLogMessage","HideLogMessages",function()
	if (not DarkRP) then bLogs:unhook("canSeeLogMessage","HideLogMessages") return end
	if (bLogs.InGameConfig) then
		if (bLogs.InGameConfig.General.DisableDarkRPLog == true) then
			return false
		end
	end
end)

function bLogs.LoadAddonModules()
	local f = file.Find("blogs/modules/addons/*.lua","LUA")
	for _,v in pairs(f) do
		include("blogs/modules/addons/" .. v)
	end
	for i,v in pairs(bLogs.InGameConfig.ModulesDisabled) do
		if (not bLogs.Modules[v]) then continue end
		bLogs.Modules[v].Enabled = false
		for _,HookData in pairs(bLogs.Modules[v].Hooks) do
			hook.Remove(HookData[1],HookData[2])
		end
	end
end
if (#player.GetAll() > 0) then
	bLogs.LoadAddonModules()
else
	hook.Add("PlayerInitialSpawn","blogs_load_addon_modules",function()
		bLogs.LoadAddonModules()
		hook.Remove("PlayerInitialSpawn","blogs_load_addon_modules")
	end)
end

local net_m = {

	-- when you start developing in some kind of camel case
	"OpenMenu",
	"Send_Setup_Data",
	"Permission_Failure",
	"SelectLogs",
	"GetOfflineName",
	"AdvancedSelectLogs",

	-- and then forget and do everything like this instead
	"start_data_flow",
	"data",
	"last_data",
	"no_data",
	"jump_to_date",
	"completed",
	"archive_logs",
	"wipe_archive",
	"reset_config",
	"update_player_format",
	"update_modules",
	"permissions",
	"permissions_update",
	"permissions_delete",
	"update_general_config",
	"update_general_config_num",
	"update_country",
	"update_config_broadcast",
	"send_log",
	"playerlookup",

} for _,v in pairs(net_m) do util.AddNetworkString("blogs_" .. v) end

bLogs.DataFlows = {}
bLogs.DataFlowing = {}

require("billyerror")

local function attach_creator_2(ply,ent)
	ent.bLogs_Creator = ply
end
local function attach_creator_3(ply,_,ent)
	ent.bLogs_Creator = ply
end
bLogs:hook("PlayerSpawnedProp","attach_to_prop",attach_creator_3)
bLogs:hook("PlayerSpawnedEffect","attach_to_effect",attach_creator_3)
bLogs:hook("PlayerSpawnedRagdoll","attach_to_ragdoll",attach_creator_3)
bLogs:hook("PlayerSpawnedNPC","attach_to_npc",attach_creator_2)
bLogs:hook("PlayerSpawnedSENT","attach_to_sent",attach_creator_2)
bLogs:hook("PlayerSpawnedSWEP","attach_to_swep",attach_creator_2)
bLogs:hook("PlayerSpawnedVehicle","attach_to_vehicle",attach_creator_2)

bLogs.Logs = {}

local function BroadcastConfigUpdate()
	local d = util.Compress(util.TableToJSON(bLogs.InGameConfig))
	local c = #d
	bLogs:nets("update_config_broadcast")
		net.WriteDouble(c)
		net.WriteData(d,c)
	net.Broadcast()
end

local function e(s)
	return sql.SQLStr(s,true)
end
local function q(query,cb)
	if (type(query) == "table") then
		local r = {}
		local i = 0
		local function s(query,i,r,cb)
			i = i + 1
			if (bLogs.Config.MySQL.Enabled) then
				local qu = bLogs.Database:query(query[i])
				qu.onSuccess = function(q,data)
					table.insert(r,data)
					if (i == #query) then
						if (cb) then
							cb(r)
						end
					else
						s(query,i,r,cb)
					end
				end
				qu.onError = function(q,err,sql)
					bLogs:print("MySQL error!: " .. err .. "\n" .. sql,"bad")
				end
				qu:start()
			else
				local data = sql.Query(query[i])
				data = data or {}
				table.insert(r,data)
				if (i == #query) then
					if (cb) then
						cb(r)
					end
				else
					s(query,i,r,cb)
				end
			end
		end
		s(query,i,r,cb)
	else
		if (not bLogs.Config) then
			bLogs:print("You probably have a config error...","bad")
			return
		end
		if (not bLogs.Config.MySQL) then
			bLogs:print("You probably have a MySQL config error...","bad")
			return
		end
		if (bLogs.Config.MySQL.Enabled) then
			local qu = bLogs.Database:query(query)
			qu.onSuccess = function(q,data)
				if (cb) then
					cb(data)
				end
			end
			qu.onError = function(q,err,sql)
				bLogs:print("MySQL error!: " .. err .. "\n" .. sql,"bad")
			end
			qu:start()
		else
			local data = sql.Query(query)
			if (cb) then
				cb(data or {})
			end
		end
	end
end

hook.Add("bLogs_FullyLoaded","blogs_insert_queued_logs",function()
	for _,v in pairs(bLogs.QueuedLogs) do
		bLogs:Log(unpack(v))
	end
	bLogs.QueuedLogs = {}
end)

local function sql_init()

	if (bLogs.Config.MySQL.Enabled) then
		bLogs:print("MySQL Database initialised","good")
	else
		bLogs:print("SQLite Database initialised","good")
	end

	bLogs:netr("Send_Setup_Data",function(ply)
		local modules  = util.Compress(util.TableToJSON(bLogs.Modules))
		local settings = util.Compress(util.TableToJSON(bLogs.InGameConfig))
		bLogs:nets("Send_Setup_Data")
			net.WriteDouble(#modules)
			net.WriteData(modules,#modules)
			net.WriteDouble(#settings)
			net.WriteData(settings,#settings)
			net.WriteBool(bLogs.Database ~= nil)
		net.Send(ply)
	end)

	bLogs:hook("PlayerSay","chatcommand",function(ply,txt)
		if (txt:lower() == bLogs.Config.ChatCommand:lower()) then
			if (bLogs:HasAccess(ply)) then
				bLogs:nets("OpenMenu")
				net.Send(ply)
			else
				bLogs:nets("permission_failure")
				net.Send(ply)
			end
			return ""
		end
	end)
	if (bLogs.Config.AllowConsoleCommand) then
		bLogs:netr("OpenMenu",function(ply)
			if (bLogs:HasAccess(ply)) then
				bLogs:nets("OpenMenu")
				net.Send(ply)
			else
				bLogs:nets("Permission_Failure")
				net.Send(ply)
			end
		end)
	end
	if (bLogs.Config.FunctionMenuKey ~= false) then
		local hook_event
		if (bLogs.Config.FunctionMenuKey == 1) then
			hook_event = "ShowHelp"
		elseif (bLogs.Config.FunctionMenuKey == 2) then
			hook_event = "ShowTeam"
		elseif (bLogs.Config.FunctionMenuKey == 3) then
			hook_event = "ShowSpare1"
		elseif (bLogs.Config.FunctionMenuKey == 4) then
			hook_event = "ShowSpare2"
		end
		bLogs:unhook("ShowHelp","functionmenukey")
		bLogs:unhook("ShowTeam","functionmenukey")
		bLogs:unhook("ShowSpare1","functionmenukey")
		bLogs:unhook("ShowSpare2","functionmenukey")
		bLogs:hook(hook_event,"functionmenukey",function(ply)
			if (bLogs:HasAccess(ply)) then
				bLogs:nets("OpenMenu")
				net.Send(ply)
			else
				bLogs:nets("Permission_Failure")
				net.Send(ply)
			end
		end)
	end

	function bLogs:Log(module,log)
		if (bLogs.InGameConfig.PrintToConsole) then
			if (bLogs.InGameConfig.PrintToConsole[module]) then
				for _,v in pairs(player.GetHumans()) do
					if (bLogs:HasAccess(v,module)) then
						bLogs:nets("send_log")
							net.WriteString(module)
							net.WriteString(log)
						net.Send(v)
					end
				end
			end
		end
		local function store()
			if (bLogs.Database) then
				q("INSERT INTO `blogs` (`module`,`log`,`time`,`session`) VALUES('" .. e(module) .. "','" .. e(log) .. "',UNIX_TIMESTAMP(),'" .. e(bLogs.Session) .. "')")
			else
				q("INSERT INTO `blogs` (`module`,`log`,`time`) VALUES('" .. e(module) .. "','" .. e(log) .. "',strftime('%s','now'))")
			end
		end
		if (log:find("{#P%|(%d+)%|#}")) then
			local stuff = {}
			for i in log:gmatch("{#P%|(%d+)%|#}") do
				table.insert(stuff,i)
			end
			local function iterate(key)
				if (not stuff[key]) then store() return end
				bLogs:OfflineName(stuff[key],function(name)
					log = (log:gsub("{#P|" .. stuff[key] .. "|#}","{#P|" .. stuff[key] .. "|" .. name .. "|#}"))
					iterate(key + 1)
				end)
			end
			iterate(1)
		else
			store()
		end
	end

	local function SelectLogs(query,page,ply)
		query = "{" .. query .. "}"
		query = util.JSONToTable(query)
		if (query) then
			local limit = bLogs.Config.LogsPerPage * page .. "," .. bLogs.Config.LogsPerPage

			local where_clause = ""

			local function cb(r)
				if (not bLogs.DataFlows[ply]) then
					bLogs.DataFlows[ply] = {}
				end
				local t = table.insert(bLogs.DataFlows[ply],r)
				local qux = ""
				if (where_clause == "") then
					if (query.archive) then
						qux = "SELECT (`var_int` / " .. bLogs.Config.LogsPerPage .. ") AS 'pages' FROM `blogs_vars` WHERE `var_name`='logs_archive'"
					else
						qux = "SELECT (`var_int` / " .. bLogs.Config.LogsPerPage .. ") AS 'pages' FROM `blogs_vars` WHERE `var_name`='logs'"
					end
				else
					if (query.archive) then
						qux = "SELECT (COUNT(`" .. bLogs.IDColumn .. "`) / " .. bLogs.Config.LogsPerPage .. ") AS 'pages' FROM `blogs_archive` WHERE " .. where_clause
					else
						qux = "SELECT (COUNT(`" .. bLogs.IDColumn .. "`) / " .. bLogs.Config.LogsPerPage .. ") AS 'pages' FROM `blogs` WHERE " .. where_clause
					end
				end
				q(qux,function(xr)
					if (#xr == 0) then
						xr[1] = {pages = 0}
					end
					bLogs:nets("start_data_flow")
						net.WriteInt(tonumber(math.ceil(xr[1].pages)),32)
					net.Send(ply)
					coroutine.resume(coroutine.create(function(t,r,ply)
						if (#r == 0) then
							bLogs:nets("no_data")
							net.Send(ply)
						else
							for i,v in pairs(r) do
								if (not bLogs.DataFlows[ply]) then break end
								bLogs:nets("data")
									net.WriteString(v.module)
									net.WriteString(v.log)
									net.WriteInt(v.time,32)
								net.Send(ply)
							end
							bLogs:nets("last_data")
							net.Send(ply)
						end
					end),t,r,ply)
				end)
			end
			local build_where_clause = {}
			if (type(query.module) == "string") then
				table.insert(build_where_clause,"`module`='" .. e(query.module) .. "'")
			end
			if (type(query.module) == "table") then
				if (#query.module == 1) then
					table.insert(build_where_clause,"`module`='" .. e(query.module[1]) .. "'")
				else
					local a = {}
					for i,v in pairs(query.module) do
						table.insert(a,"`module`='" .. e(v) .. "'")
					end
					for i,v in pairs(a) do
						if (i == 1) then
							table.insert(build_where_clause,"(")
							table.insert(build_where_clause,v)
						elseif (i == #a) then
							table.insert(build_where_clause,v)
							table.insert(build_where_clause,")")
						else
							table.insert(build_where_clause,"(")
							table.insert(build_where_clause,v)
						end
					end
				end
			end
			if (query.search) then
				table.insert(build_where_clause,"`log` LIKE '%" .. (e(query.search):gsub("%%","\\%%")) .. "%'")
			end
			if (type(query.player) == "string") then
				table.insert(build_where_clause,"`log` LIKE '%{#P|" .. (e(query.player):gsub("%%","\\%%")) .. "%'")
			end
			if (type(query.player) == "table") then
				if (#query.player == 1) then
					table.insert(build_where_clause,"`log` LIKE '%{#P|" .. (e(query.player[1]):gsub("%%","\\%%")) .. "%'")
				else
					local a = {}
					for i,v in pairs(query.player) do
						table.insert(a,"`log` LIKE '%{#P|" .. (e(v):gsub("%%","\\%%")) .. "%'")
					end
					for i,v in pairs(a) do
						if (i == 1) then
							table.insert(build_where_clause,"(")
							table.insert(build_where_clause,v)
						elseif (i == #a) then
							table.insert(build_where_clause,v)
							table.insert(build_where_clause,")")
						else
							table.insert(build_where_clause,"(")
							table.insert(build_where_clause,v)
						end
					end
				end
			end
			local open_bracket = false
			local open_bracket_i = 0
			for i,v in pairs(build_where_clause) do
				if (i == 1) then
					where_clause = v
				elseif (v == "(") then
					where_clause = where_clause .. " AND ("
					open_bracket = true
				elseif (v == ")") then
					where_clause = where_clause .. ")"
					open_bracket = false
					open_bracket_i = 0
				elseif (open_bracket) then
					open_bracket_i = open_bracket_i + 1
					if (open_bracket_i == 1) then
						where_clause = where_clause .. v
					else
						where_clause = where_clause .. " OR " .. v
					end
				else
					where_clause = where_clause .. " AND " .. v
				end
			end
			local tbl = "blogs"
			if (query.archive) then
				tbl = "blogs_archive"
			end
			if (where_clause == "") then
				q("SELECT `module`,`log`,`time` FROM `" .. tbl .. "` ORDER BY `time` DESC LIMIT " .. limit,cb)
			else
				q("SELECT `module`,`log`,`time` FROM `" .. tbl .. "` WHERE " .. where_clause .. " ORDER BY `time` DESC LIMIT " .. limit,cb)
			end
		end
	end

	bLogs:netr("AdvancedSelectLogs",function(ply)
		local d = net.ReadDouble()
		local ds = net.ReadData(d)
		local p = net.ReadInt(32) - 1

		ds = util.Decompress(ds)

		SelectLogs(ds,p,ply)
	end)
	bLogs:netr("SelectLogs",function(ply)
		local query = net.ReadString()
		local page  = net.ReadInt(32) - 1

		SelectLogs(query,page,ply)
	end)
	bLogs:netr("last_data",function(ply)
		if (not bLogs.DataFlows[ply]) then return end
		bLogs.DataFlows[ply] = nil
	end)

	bLogs:netr("playerlookup",function(ply)
		if (not bLogs:HasAccess(ply)) then return end
		local data = table.Copy(bLogs.PlayerLookup)
		if (not bLogs:HasAccess(ply,"IPAddresses")) then
			for i in pairs(data) do
				data[i].IP_Address = nil
			end
		end
		data = util.TableToJSON(data)
		data = util.Compress(data)
		local d = #data
		bLogs:nets("playerlookup")
			net.WriteDouble(d)
			net.WriteData(data,d)
		net.Send(ply)
	end)

	bLogs:netr("jump_to_date",function(ply)
		local t = net.ReadString()
		t = util.JSONToTable(t)

		local s = "%s/%s/%s %s:%s"
		s = s:format(
			t.day,
			t.month,
			t.year,
			t.hour,
			t.min
		)

		q("SELECT (SELECT CEIL(`" .. bLogs.IDColumn .. "` / 60) AS `pages` FROM `blogs` ORDER BY `time` DESC LIMIT 1) - FLOOR(`" .. bLogs.IDColumn .. "` / 60) AS `page` FROM `blogs` WHERE `time` <= unix_timestamp(str_to_date('" .. e(s) .. "','%d/%m/%Y %H:%i')) ORDER BY `time` DESC LIMIT 1",function(r)
			if (#r == 0) then
				bLogs:nets("no_data")
				net.Send(ply)
			else
				bLogs:nets("jump_to_date")
					net.WriteInt(r[1].page,32)
				net.Send(ply)
			end
		end)
	end)

	bLogs:netr("archive_logs",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		if (bLogs.Database) then
			q([[

				INSERT INTO `blogs_archive` (`module`,`log`,`time`) SELECT `module`,`log`,`time` FROM `blogs` ORDER BY `blogs`.`time` ASC;
				TRUNCATE `blogs`;
				UPDATE `blogs_vars` SET `var_int`=0 WHERE `var_name`='logs';
				UPDATE `blogs_vars` SET `var_int`=(SELECT COUNT(`id`) FROM `blogs_archive`) WHERE `var_name`='logs_archive';

			]],function()

				bLogs:nets("completed")
				net.Send(ply)

			end)
		else
			q([[

				INSERT INTO `blogs_archive` (`module`,`log`,`time`) SELECT `module`,`log`,`time` FROM `blogs` ORDER BY `blogs`.`time` ASC;
				DELETE FROM `blogs`; VACUUM;
				UPDATE `blogs_vars` SET `var_int`=0 WHERE `var_name`='logs';
				UPDATE `blogs_vars` SET `var_int`=(SELECT COUNT(`ROWID`) FROM `blogs_archive`) WHERE `var_name`='logs_archive';

			]],function()

				bLogs:nets("completed")
				net.Send(ply)

			end)
		end
	end)

	bLogs:netr("wipe_archive",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		if (bLogs.Database) then
			q([[

				TRUNCATE `blogs_archive`;

				UPDATE `blogs_vars` SET `var_int`=0 WHERE `var_name`='logs_archive';

			]],function()

				bLogs:nets("completed")
				net.Send(ply)

			end)
		else
			q([[

				DELETE FROM `blogs_archive`; VACUUM;

				UPDATE `blogs_vars` SET `var_int`=0 WHERE `var_name`='logs_archive';

			]],function()

				bLogs:nets("completed")
				net.Send(ply)

			end)
		end
	end)

	bLogs:netr("reset_config",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		bLogs.InGameConfig = bLogs.DefaultInGameConfig

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.DefaultInGameConfig))

		bLogs:nets("completed")
		net.Send(ply)
	end)

	bLogs:netr("update_general_config",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local key   = net.ReadString()
		local value = net.ReadBool()

		bLogs.InGameConfig.General[key] = value

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)
	bLogs:netr("update_general_config_num",function()
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local key   = net.ReadString()
		local value = net.ReadInt(32)

		bLogs.InGameConfig.General[key] = value

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)

	bLogs:netr("update_player_format",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local key   = net.ReadString()
		local value = net.ReadBool()

		bLogs.InGameConfig.Info[key] = value

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)

	bLogs:netr("update_modules",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local n = net.ReadString()
		local disabled = net.ReadBool()
		local print_to_console = net.ReadBool()

		bLogs.InGameConfig.ModulesDisabled[n] = disabled or nil
		bLogs.InGameConfig.PrintToConsole[n] = print_to_console or nil

		if (disabled) then
			for _,HookData in pairs(bLogs.Modules[n].Hooks) do
				hook.Remove(HookData[1],HookData[2])
			end
		else
			include(bLogs.Modules[n].File)
		end

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()

		--[[local n = net.ReadDouble()
		local d = net.ReadData(n)

		bLogs:nets("update_modules")
			net.WriteDouble(n)
			net.WriteData(d,n)
		net.Broadcast()

		d = util.Decompress(d)
		d = util.JSONToTable(d)

		--for _,DisabledModule in pairs(d.disabled) do

			for ModuleKey,ModuleData in pairs(bLogs.Modules) do

				--if (ModuleKey ~= DisabledModule) then continue end

				--bLogs.Modules[ModuleKey].Enabled = false

				for _,HookData in pairs(ModuleData.Hooks) do
					hook.Remove(HookData[1],HookData[2])
				end

			end

		--end

		--[[for _,EnabledModule in pairs(d.enabled) do

			for ModuleKey,ModuleData in pairs(bLogs.Modules) do

				if (ModuleKey ~= DisabledModule) then continue end

				bLogs.Modules[ModuleKey].Enabled = true

				for _,HookData in pairs(ModuleData.Hooks) do
					hook.Add(HookData[1],HookData[2],HookData[3])
				end

			end

		end--]]

		--[[bLogs.InGameConfig.ModulesDisabled = d.disabled

		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()

		bLogs.LoadModules()
		bLogs.LoadDelayedModules()
		bLogs.LoadAddonModules()]]

	end)

	bLogs.DefaultPermissions = {
		Menu = false,
		IPAddresses = false,
	}

	bLogs:netr("permissions",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local type = net.ReadInt(16)
		local data = net.ReadString()
		if (type == 1) then
			-- Job
			if (not tonumber(data)) then
				bLogs:print("This shouldn't be happening! Please make a ticket and show this: " .. tostring(data),"bad")
			end
			data = tonumber(data)
			if (RPExtraTeams[data]) then
				data = RPExtraTeams[data].name
				if (not bLogs.InGameConfig.Permissions.Jobs[data]) then
					bLogs.InGameConfig.Permissions.Jobs[data] = table.Copy(bLogs.DefaultPermissions)
				end
				for i in pairs(bLogs.Modules) do
					if (bLogs.InGameConfig.Permissions.Jobs[data][i] == nil) then
						bLogs.InGameConfig.Permissions.Jobs[data][i] = false
					end
				end
				for i,v in pairs(bLogs.DefaultPermissions) do
					if (bLogs.InGameConfig.Permissions.Jobs[data][i] == nil) then
						bLogs.InGameConfig.Permissions.Jobs[data][i] = v
					end
				end
				local c = util.Compress(util.TableToJSON(bLogs.InGameConfig.Permissions.Jobs[data]))
				local d = #c
				bLogs:nets("permissions")
					net.WriteDouble(d)
					net.WriteData(c,d)
				net.Send(ply)
			end
		elseif (type == 2 or type == 4 or type == 5) then
			-- CAMI/Usergroup
			if (not bLogs.InGameConfig.Permissions.Usergroups[data]) then
				bLogs.InGameConfig.Permissions.Usergroups[data] = table.Copy(bLogs.DefaultPermissions)
			end
			for i in pairs(bLogs.Modules) do
				if (bLogs.InGameConfig.Permissions.Usergroups[data][i] == nil) then
					bLogs.InGameConfig.Permissions.Usergroups[data][i] = false
				end
			end
			for i,v in pairs(bLogs.DefaultPermissions) do
				if (bLogs.InGameConfig.Permissions.Usergroups[data][i] == nil) then
					bLogs.InGameConfig.Permissions.Usergroups[data][i] = v
				end
			end
			local c = util.Compress(util.TableToJSON(bLogs.InGameConfig.Permissions.Usergroups[data]))
			local d = #c
			bLogs:nets("permissions")
				net.WriteDouble(d)
				net.WriteData(c,d)
			net.Send(ply)
		elseif (type == 3 or type == 6 and data:find("^STEAM_%d:%d:%d+$")) then
			-- SteamID
			if (not bLogs.InGameConfig.Permissions.SteamIDs[data]) then
				bLogs.InGameConfig.Permissions.SteamIDs[data] = table.Copy(bLogs.DefaultPermissions)
			end
			for i in pairs(bLogs.Modules) do
				if (bLogs.InGameConfig.Permissions.SteamIDs[data][i] == nil) then
					bLogs.InGameConfig.Permissions.SteamIDs[data][i] = false
				end
			end
			for i,v in pairs(bLogs.DefaultPermissions) do
				if (bLogs.InGameConfig.Permissions.SteamIDs[data][i] == nil) then
					bLogs.InGameConfig.Permissions.SteamIDs[data][i] = v
				end
			end
			local c = util.Compress(util.TableToJSON(bLogs.InGameConfig.Permissions.SteamIDs[data]))
			local d = #c
			bLogs:nets("permissions")
				net.WriteDouble(d)
				net.WriteData(c,d)
			net.Send(ply)
		end
		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)

	bLogs:netr("permissions_update",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local key = net.ReadString()
		local per = net.ReadString()
		local val = net.ReadBool()
		per = ({
			["## Open Menu"] = "Menu",
			["## See IP Addresses"] = "IPAddresses",
		})[per] or per
		if (per:find("^.-: .-$")) then
			per = (per:gsub("^(.-): (.-)$","%1_%2"))
		end
		if (key:sub(1,5) == "Job: " or key:sub(1,6) == "Team: ") then
			local x
			if (key:sub(1,5) == "Job: ") then
				x = key:sub(6)
			else
				x = key:sub(7)
			end
			for _,v in pairs(RPExtraTeams) do
				if (v.name == x) then
					bLogs.InGameConfig.Permissions.Jobs[v.name][per] = val
					break
				end
			end
		elseif (key:sub(1,6) == "CAMI: ") then
			bLogs.InGameConfig.Permissions.Usergroups[key:sub(7)][per] = val
		elseif (key:sub(1,9) == "SteamID: ") then
			bLogs.InGameConfig.Permissions.SteamIDs[key:sub(10)][per] = val
		elseif (key:sub(1,11) == "Usergroup: ") then
			bLogs.InGameConfig.Permissions.Usergroups[key:sub(12)][per] = val
		end
		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)

	bLogs:netr("permissions_delete",function(ply)
		if (not bLogs:IsMaxPermitted(ply)) then return end

		local key = net.ReadString()

		if (key:sub(1,5) == "Job: " or key:sub(1,6) == "Team: ") then
			local x
			if (key:sub(1,5) == "Job: ") then
				x = key:sub(6)
			else
				x = key:sub(7)
			end
			for _,v in pairs(RPExtraTeams) do
				if (v.name == x) then
					bLogs.InGameConfig.Permissions.Jobs[v.name] = nil
					break
				end
			end
		elseif (key:sub(1,6) == "CAMI: ") then
			bLogs.InGameConfig.Permissions.Usergroups[key:sub(7)] = nil
		elseif (key:sub(1,9) == "SteamID: ") then
			bLogs.InGameConfig.Permissions.SteamIDs[key:sub(10)] = nil
		elseif (key:sub(1,11) == "Usergroup: ") then
			bLogs.InGameConfig.Permissions.Usergroups[key:sub(12)] = nil
		end
		file.Write("blogs/config.txt",util.TableToJSON(bLogs.InGameConfig))
		BroadcastConfigUpdate()
	end)

	hook.Run("bLogs_FullyLoaded")

end

include("blogs_mysql_config.lua")
if (bLogs.Config.MySQL.Enabled) then
	if (system.IsWindows()) then
		if (not file.Exists("bin/gmsv_mysqloo_win32.dll","LUA")) then
			bLogs.Config.MySQL = false
			if (file.Exists("bin/gmsv_mysqloo_linux.dll","LUA")) then
				BillyError("bLogs","Why have you installed the Linux version of mysqloo when your server is running Windows?")
			else
				BillyError("bLogs","You don't have mysqloo installed, but have MySQL enabled.")
			end
		else
			local worked,err = pcall(require,"mysqloo")
			if (worked) then
				require("mysqloo")
			elseif (err == "Couldn't load module library!") then
				bLogs.Config.MySQL = false
				BillyError("bLogs","You don't have libmysql.dll installed. https://facepunch.com/showthread.php?t=1515853")
			end
			bLogs:print("Initialized mysqloo","good")
		end
	end
	if (system.IsLinux()) then
		if (not file.Exists("bin/gmsv_mysqloo_linux.dll","LUA")) then
			bLogs.Config.MySQL = false
			if (file.Exists("bin/gmsv_mysqloo_win32.dll","LUA")) then
				BillyError("bLogs","Why have you installed the Windows version of mysqloo when your server is running Linux?")
			else
				BillyError("bLogs","You don't have mysqloo installed, but have MySQL enabled.")
			end
		else
			local worked,err = pcall(require,"mysqloo")
			if (worked) then
				require("mysqloo")
			elseif (err == "Couldn't load module library!") then
				bLogs.Config.MySQL = false
				BillyError("bLogs","You don't have libmysqlclient.so installed. https://facepunch.com/showthread.php?t=1515853")
			end
			bLogs:print("Initialized mysqloo","good")
		end
	end
end
if (bLogs.Config.MySQL.Enabled) then
	bLogs.IDColumn = "id"
	if (bLogs.Config.MySQL.Host) then
		if (type(bLogs.Config.MySQL.Host) ~= "string") then
			BillyError("bLogs","You have an error in your MySQL config related to config.Host.")
		end
	else
		BillyError("bLogs","You have an error in your MySQL config related to config.Host. It is not a string.")
	end
	if (bLogs.Config.MySQL.Username) then
		if (type(bLogs.Config.MySQL.Username) ~= "string") then
			BillyError("bLogs","You have an error in your MySQL config related to config.Username.")
		end
	else
		BillyError("bLogs","You have an error in your MySQL config related to config.Username. It is not a string.")
	end
	if (bLogs.Config.MySQL.Password) then
		if (type(bLogs.Config.MySQL.Password) ~= "string") then
			BillyError("bLogs","You have an error in your MySQL config related to config.Password.")
		end
	else
		BillyError("bLogs","You have an error in your MySQL config related to config.Password.")
	end
	if (bLogs.Config.MySQL.Database) then
		if (type(bLogs.Config.MySQL.Database) ~= "string") then
			BillyError("bLogs","You have an error in your MySQL config related to config.Database. It is not a string.")
		end
	else
		BillyError("bLogs","You have an error in your MySQL config related to config.Database.")
	end
	if (bLogs.Config.MySQL.Port) then
		if (type(bLogs.Config.MySQL.Port) ~= "number") then
			BillyError("bLogs","You have an error in your MySQL config related to config.Port. It is not a number.")
		end
	else
		BillyError("bLogs","You have an error in your MySQL config related to config.Port.")
	end
	bLogs.Database = mysqloo.connect(
		bLogs.Config.MySQL.Host,
		bLogs.Config.MySQL.Username,
		bLogs.Config.MySQL.Password,
		bLogs.Config.MySQL.Database,
		bLogs.Config.MySQL.Port
	)
	bLogs:print("Connecting to remote database...")
	bLogs.Database.onConnectionFailed = function(_,err)
		BillyError("bLogs","There was an error connecting to your MySQL server. The error was:\n\n" .. err .. "\n\nThe script is still running but is not using MySQL.")
		bLogs.Database = nil
		sql_init()
	end
	bLogs.Database.onConnected = function()
		bLogs:print("Successfully connected to remote database on " .. bLogs.Config.MySQL.Host .. ":" .. bLogs.Config.MySQL.Port .. ".","good")

		q([[

			CREATE TABLE IF NOT EXISTS `blogs` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`session` int(11) NOT NULL,
				`module` varchar(255) NOT NULL,
				`log` text CHARACTER SET utf8mb4 NOT NULL,
				`time` int(11) NOT NULL,
				PRIMARY KEY (`id`)
			);

			CREATE TABLE IF NOT EXISTS `blogs_archive` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`module` varchar(255) NOT NULL,
				`log` text CHARACTER SET utf8mb4 NOT NULL,
				`time` int(11) NOT NULL,
				PRIMARY KEY (`id`)
			);

			CREATE TABLE IF NOT EXISTS `blogs_vars` (
				`var_name` varchar(255) NOT NULL,
				`var_str` varchar(255) NOT NULL,
				`var_int` int(11) NOT NULL,
				PRIMARY KEY (`var_name`)
			);

			DROP PROCEDURE IF EXISTS SCHEMA_CHANGE;

			CREATE PROCEDURE SCHEMA_CHANGE() BEGIN

				IF EXISTS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='blogs' AND COLUMN_NAME='ROWID' AND TABLE_SCHEMA=']] .. e(bLogs.Config.MySQL.Database) .. [[') THEN
					ALTER TABLE `blogs` CHANGE `ROWID` `id` INT(11) NOT NULL AUTO_INCREMENT;
				END IF;

				IF EXISTS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_NAME='blogs_archive' AND COLUMN_NAME='ROWID' AND TABLE_SCHEMA=']] .. e(bLogs.Config.MySQL.Database) .. [[') THEN
					ALTER TABLE `blogs_archive` CHANGE `ROWID` `id` INT(11) NOT NULL AUTO_INCREMENT;
				END IF;

			END;

			CALL SCHEMA_CHANGE();

			DROP PROCEDURE IF EXISTS SCHEMA_CHANGE;

			INSERT IGNORE INTO `blogs_vars` (`var_name`,`var_str`,`var_int`) VALUES ('logs','','0');

			INSERT IGNORE INTO `blogs_vars` (`var_name`,`var_str`,`var_int`) VALUES ('session','','0');

			INSERT IGNORE INTO `blogs_vars` (`var_name`,`var_str`,`var_int`) VALUES ('logs_archive','','0');

			CREATE TABLE IF NOT EXISTS `blogs_players` (
				`steamid64` varchar(255) NOT NULL,
				`name` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
				PRIMARY KEY (`steamid64`)
			);

			DROP TRIGGER IF EXISTS lognum_add;
			DROP TRIGGER IF EXISTS lognum_sub;

			DROP TRIGGER IF EXISTS lognum_add_archive;
			DROP TRIGGER IF EXISTS lognum_sub_archive;

			UPDATE `blogs_vars` SET `var_int`=`var_int` + 1 WHERE `var_name`='session';
			INSERT INTO `blogs_archive` (`module`,`log`,`time`) SELECT `module`,`log`,`time` FROM `blogs` WHERE `session` != (SELECT `var_int` FROM `blogs_vars` WHERE `var_name`='session') ORDER BY `blogs`.`time` ASC;
			TRUNCATE `blogs`;

			CREATE TRIGGER lognum_add AFTER INSERT ON `blogs` FOR EACH ROW UPDATE `blogs_vars` SET `var_int`=`var_int`+1 WHERE `var_name`='logs';
			CREATE TRIGGER lognum_sub AFTER DELETE ON `blogs` FOR EACH ROW UPDATE `blogs_vars` SET `var_int`=`var_int`-1 WHERE `var_name`='logs';
			CREATE TRIGGER lognum_add_archive AFTER INSERT ON `blogs_archive` FOR EACH ROW UPDATE `blogs_vars` SET `var_int`=`var_int`+1 WHERE `var_name`='logs_archive';
			CREATE TRIGGER lognum_sub_archive AFTER DELETE ON `blogs_archive` FOR EACH ROW UPDATE `blogs_vars` SET `var_int`=`var_int`-1 WHERE `var_name`='logs_archive';

		]],function()

			if (bLogs.InGameConfig.General.AutoDeleteEnabled) then
				local s = bLogs.InGameConfig.General.AutoDelete * 86400
				q("DELETE FROM `blogs_archive` WHERE `time` < (UNIX_TIMESTAMP() - " .. s .. ")")
			end

			if (bLogs.InGameConfig.General.VolatileLogs) then
				q("TRUNCATE `blogs_archive`")
			end

			local function print_info()
				q("SELECT COUNT(`id`) FROM `blogs`",function(r)
					q("UPDATE `blogs_vars` SET `var_int`='" .. e(r[1]["COUNT(`id`)"]) .. "' WHERE `var_name`='logs'",function()
						q("SELECT COUNT(`id`) FROM `blogs_archive`",function(r)
							q("UPDATE `blogs_vars` SET `var_int`='" .. e(r[1]["COUNT(`id`)"]) .. "' WHERE `var_name`='logs_archive'",function()

								q("SELECT `var_name`,`var_int` FROM `blogs_vars` WHERE `var_name`='session' OR `var_name`='logs' OR `var_name`='logs_archive'",function(r)
									for _,v in pairs(r) do
										if (v.var_name == "session") then
											bLogs.Session = v.var_int
											bLogs:print("Session #    : " .. v.var_int)
										elseif (v.var_name == "logs") then
											bLogs:print("Active Logs  : " .. v.var_int)
										elseif (v.var_name == "logs_archive") then
											bLogs:print("Archived Logs: " .. v.var_int)
										end
									end
									sql_init()
								end)

							end)
						end)
					end)
				end)
			end

			print_info()

		end)
	end
	bLogs.Database:connect()
else
	bLogs.IDColumn = "ROWID"

	q({

		[[
			CREATE TABLE IF NOT EXISTS `blogs` (
				`module` varchar NOT NULL,
				`log` text NOT NULL,
				`time` int NOT NULL
			)
		]],

		[[
			CREATE TABLE IF NOT EXISTS `blogs_archive` (
				`module` varchar NOT NULL,
				`log` text NOT NULL,
				`time` int NOT NULL
			)
		]],

		[[
			CREATE TABLE IF NOT EXISTS `blogs_vars` (
				`var_name` varchar NOT NULL,
				`var_str` varchar NOT NULL,
				`var_int` int NOT NULL,
				PRIMARY KEY (`var_name`)
			)
		]],

		"INSERT OR IGNORE INTO `blogs_vars` (`var_name`,`var_str`,`var_int`) VALUES ('logs','','0')",
		"INSERT OR IGNORE INTO `blogs_vars` (`var_name`,`var_str`,`var_int`) VALUES ('logs_archive','','0')",

		[[
			CREATE TABLE IF NOT EXISTS `blogs_players` (
				`steamid64`  NOT NULL,
				`name` NOT NULL,
				PRIMARY KEY (`steamid64`)
			)
		]],

		"DELETE FROM `blogs_archive`",
		"VACUUM",

		"INSERT INTO `blogs_archive` (`module`,`log`,`time`) SELECT `module`,`log`,`time` FROM `blogs` ORDER BY `blogs`.`time` ASC",

		"UPDATE `blogs_vars` SET `var_int`=(SELECT COUNT(`ROWID`) FROM `blogs_archive`) WHERE `var_name`='logs_archive'",

		"DELETE FROM `blogs`",
		"VACUUM",

		"CREATE TRIGGER IF NOT EXISTS lognum_add AFTER INSERT ON `blogs` FOR EACH ROW BEGIN UPDATE `blogs_vars` SET `var_int`=`var_int`+1 WHERE `var_name`='logs'; END",
		"CREATE TRIGGER IF NOT EXISTS lognum_sub AFTER DELETE ON `blogs` FOR EACH ROW BEGIN UPDATE `blogs_vars` SET `var_int`=`var_int`-1 WHERE `var_name`='logs'; END",

	},function()

		sql_init()

	end)
end