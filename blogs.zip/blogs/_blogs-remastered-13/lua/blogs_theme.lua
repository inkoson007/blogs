bLogs_ThemeColor     = Color(52,139,249)
bLogs_SecondaryColor = Color(26,26,26)

bLogs_ButtonHovered  = Color(38,103,183)
bLogs_ButtonClick    = Color(96,168,255)

bLogs_PlayerColor    = "52,139,249,255"
bLogs_VehicleColor   = "153,58,0,255"
bLogs_EntityColor    = "150,75,0,255"
bLogs_MoneyColor     = "0,150,0,255"
bLogs_HighlightColor = "136,7,0,255"
